#include "sistema.h"

void Astros::getAstro(){

	glPushMatrix();
	glRotatef ((GLfloat) this->year, 0.0, 1.0, 0.0);
	glTranslatef (this->Raio * this->orbita, 0.0, 0.0);
	glRotatef ((GLfloat) this->day, 0.0, 1.0, 0.0);
	glColor3f (0.0, 1.0, 0.6);//azul
	glutWireSphere(this->Raio,this->numPCir,this->numDCir);

	cout<< "render astro: " << this->t << endl;

	if(this->qtdSatelites > 0){
		for(int i = 0; i < this->qtdSatelites; i++){
			this->satelites[i]->getAstro();
		}
	}

	glPopMatrix();


}

double Astros::Random(){

	if(min > max){
		double A;
		A=this->min;
		this->min = this->max;
		this->max=A;
	}
	return ( ((double)rand()/(double)(RAND_MAX))*(this->max-this->min) )+this->max;
}

void Astros::criarSatelite(){

	
	cout << "Criou satelite!" << endl;


}

Lua::Lua(){

	this->t = "Lua";
	this->qtdSatelites = 0;
	this->satelites = NULL;
	this->min =	0.05;  
	this->max =	0.10; 
	this->Raio = this->Random();

}


Planeta::Planeta(int aQtdLuas){

	this->t = "Planeta";
	this->qtdSatelites = aQtdLuas;

	this->satelites = new Astros*[this->qtdSatelites];

	this->min =	0.15;   
	this->max =	0.25; 
	this->Raio = this->Random();

	this->orbita = 2;

	this->criarSatelite();

}

Planeta::Planeta(int aQtdLuas,int aOrbita){

	this->t = "Planeta";
	this->qtdSatelites = aQtdLuas;

	this->satelites = new Astros*[this->qtdSatelites];

	this->min =	0.15;   
	this->max =	0.25; 
	this->Raio = this->Random();

	this->orbita = (2 * aOrbita);

	this->criarSatelite();

}

void Planeta::criarSatelite(){

	if(this->qtdSatelites > 0){

		for(int i = 0; i < this->qtdSatelites; i++){
			this->satelites[i] = new Lua();
		}
	}



}


PlanetaGas::PlanetaGas(int aQtdLuas){

	this->t = "Planeta gas";

	this->qtdSatelites = aQtdLuas;

	this->satelites = new Astros*[this->qtdSatelites];

	this->min =	0.30;   
	this->min =	0.50; 
	this->Raio = this->Random();

	this->criarSatelite();

}

void PlanetaGas::criarSatelite(){

	if(this->qtdSatelites > 0){

		for(int i = 0; i < this->qtdSatelites; i++){
			this->satelites[i] = new Lua();
		}
	}
}

Strela::Strela(int aQtdPlanetas){


	this->t = "Strela";
	this->qtdSatelites = aQtdPlanetas;

	this->satelites = new Astros*[this->qtdSatelites];

	this->min =	0.70;   
	this->min =	1.20; 
	this->Raio = this->Random();

	this->criarSatelite();

}


void Strela::criarSatelite(){

	//incializa os planetas
	if(this->qtdSatelites > 0){

   		//glColor3f (0.0, 1.0, 0.6);//azul
		this->satelites[0] = new Planeta(0,1);
		this->satelites[1] = new Planeta(1,2);
		this->satelites[2] = new Planeta(3,3);
		this->satelites[3] = new Planeta(4,4);
		//this->satelites[2] = new PlanetaGas(3);
		//this->satelites[3] = new PlanetaGas(4);
	}


}

void Strela::getAstro(){

	glColor3f (1.0, 1.0, 0.0);//amarelo
	glutWireSphere(this->Raio,this->numPCir,this->numDCir);
	cout<< "render astro: " << this->t << endl;

	if(this->qtdSatelites > 0){
		for(int i = 0; i < this->qtdSatelites; i++)
			this->satelites[i]->getAstro();
	}

}



Sistema::Sistema(){

	

}


void Sistema::setSistema(){


	//inicializar estrelas
	this->estrela = new Strela(4);

}


void Sistema::getSistema(int year, int day, int lum){

	for(int i = 0; i< this->estrela->qtdSatelites;i++)
	{
		this->estrela->satelites[i]->year = year;
		this->estrela->satelites[i]->day = day;
		this->estrela->satelites[i]->lum = lum;
	}
	
	this->estrela->getAstro();

}
