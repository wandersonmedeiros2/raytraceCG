#include <iostream>
#include <cmath>
#include <GL/glut.h>
#include <GL/gl.h>

using namespace std;

#ifndef SISTEMA_H
#define SISTEMA_H



class Astros{
	
	public:
		char* t;
		int numPCir = 20; 
		int numDCir = 16;

		double min;
		double max;

		double Raio;
		double distOrb = 0;
		double angOrb  = 0;

		double orbita;
		
		int qtdSatelites;
		Astros** satelites;

		int year;
		int day;
	    int lum;

		double Random();
		virtual void criarSatelite();
		void getAstro();
};



class Lua : public Astros
{
	public:
		Lua();	
};


class Planeta : public Astros
{

	public:
		Planeta(int aQtdLuas);
		Planeta(int aQtdLuas,int aOrbita);
		void criarSatelite();	
		
	
};



class PlanetaGas : public Astros
{
	public:
		PlanetaGas(int aQtdLuas);
		void criarSatelite();


	
};

class Strela : public Astros
{

	public:
		Strela(int aQtdPlanetas);
		void criarSatelite();
		void getAstro();
	
};

class Sistema
{
	protected:
		Strela *estrela;

	public:

		
	//public Lua, public Planeta, public PlanetaGas, public Strela
	Sistema();
	void setSistema();
	void getSistema(int year, int day, int lum);
	void getSistema();
};

#endif